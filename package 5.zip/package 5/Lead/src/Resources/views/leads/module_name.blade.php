<option  value="Lead" >{{__('Lead')}}</option>
<option  value="Deal" >{{__('Deal')}}</option>
