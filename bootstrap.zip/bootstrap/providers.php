<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\AuthServiceProvider::class,
    App\Providers\EventServiceProvider::class,
    App\Providers\PackageServiceProvider::class,
    App\Providers\RouteServiceProvider::class,
];
