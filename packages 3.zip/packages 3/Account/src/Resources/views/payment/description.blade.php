<div class="modal-body">
    <div class="row">
        <div class="form-group mb-0">
            <p class="p-3">{{$payment->description ?? '-'}}</p>
        </div>
    </div>
</div>
