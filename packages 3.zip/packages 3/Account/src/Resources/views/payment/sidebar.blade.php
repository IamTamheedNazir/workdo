<li class="nav-item">
    <a href="#" class="nav-link" data-bs-toggle="tab"
        data-bs-target="#bankaccount-payment" role="tab"
        aria-controls="bankaccount" aria-selected="false">{{ __('Bank Details') }}
    </a>
</li>
