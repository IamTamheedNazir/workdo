@permission('category manage')
    <a href="#category-settings" class="list-group-item list-group-item-action dash-link ">{{ __('Category') }} <div
            class="float-end"><i class="ti ti-chevron-right"></i></div></a>
@endpermission
