@permission('tax manage')
    <a href="#tax-settings" class="list-group-item list-group-item-action dash-link ">{{ __('Tax') }} <div
            class="float-end"><i class="ti ti-chevron-right"></i></div></a>
@endpermission
