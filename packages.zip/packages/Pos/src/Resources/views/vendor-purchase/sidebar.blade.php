<li class="nav-item" role="presentation">
    <button class="nav-link " id="vendor-purchase-tab"
        data-bs-toggle="pill" data-bs-target="#vendor-purchase"
        type="button">{{ __('Purchase') }}</button>
</li>
