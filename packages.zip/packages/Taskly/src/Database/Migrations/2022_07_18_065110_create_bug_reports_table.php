<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBugReportsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(!Schema::hasTable('bug_reports'))
        {
            Schema::create('bug_reports', function (Blueprint $table) {
                $table->id();
                $table->string('title');
                $table->string('priority');
                $table->text('description');
                $table->integer('assign_to');
                $table->integer('project_id');
                $table->string('status')->default('unconfirmed');
                $table->integer('order')->default(0);
                $table->timestamps();
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('bug_reports');
    }
}
