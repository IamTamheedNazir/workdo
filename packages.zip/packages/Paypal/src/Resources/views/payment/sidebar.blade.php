<li class="nav-item">
    <a href="#" class="nav-link" data-bs-toggle="tab"
        data-bs-target="#paypal-payment" role="tab"
        aria-controls="paypal" aria-selected="false">{{ __('Paypal') }}
    </a>
</li>
