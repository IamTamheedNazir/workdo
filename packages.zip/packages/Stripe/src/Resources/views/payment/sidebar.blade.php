
<li class="nav-item">
    <a class=" nav-link" id="pills-home-tab" data-bs-toggle="pill"
        data-bs-target="#stripe-payment" type="button" role="tab"
        aria-controls="pills-home" aria-selected="true">{{ __('Stripe') }}</a>
</li>

