<?php

namespace Workdo\Stripe\Providers;

use Illuminate\Support\ServiceProvider;
use App\Models\WorkSpace;

class FacilitiesSerivceProvider extends ServiceProvider
{
    /**
     * Register the service provider.
     *
     * @return void
     */
    public function boot(){

        view()->composer(['facilities::frontend.append'], function ($view)
        {
                $slug = \Request::segment(2);
                $workspace = WorkSpace::where('id',$slug)->first();
                $company_settings = getCompanyAllSetting($workspace->created_by,$workspace->id);
                if((isset($company_settings['stripe_is_on']) ? $company_settings['stripe_is_on'] : 'off') == 'on' && !empty($company_settings['stripe_key']) && !empty($company_settings['stripe_secret']))
                {
                    $view->getFactory()->startPush('facilities_payment', view('stripe::payment.facilities_payment',compact('slug')));
                }
        });
    }

    public function register()
    {
        //
    }

    /**
     * Get the services provided by the provider.
     *
     * @return array
     */
    public function provides()
    {
        return [];
    }
}
