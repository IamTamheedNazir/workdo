<?php

return [
    'system' => 'WorkDo Dash SaaS',
    'system_version' => '6.6',
];
