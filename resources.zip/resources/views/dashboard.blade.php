@extends('layouts.main')
@section('page-title')
{{ __('Dashboard')}}
@endsection
@section('content')
@endsection
