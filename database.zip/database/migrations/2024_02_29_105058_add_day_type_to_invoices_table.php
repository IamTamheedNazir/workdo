<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (Schema::hasTable('invoices') && !Schema::hasColumn('invoices', 'day_type','start_date','end_date')) {
            Schema::table('invoices', function (Blueprint $table) {
                $table->integer('day_type')->default(1)->nullable()->after('shipping_display');
                $table->date('start_date')->nullable()->after('day_type');
                $table->date('end_date')->nullable()->after('start_date');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('invoices', function (Blueprint $table) {
            //
        });
    }
};
